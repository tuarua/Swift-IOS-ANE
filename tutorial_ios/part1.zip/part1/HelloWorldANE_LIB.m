#import "FreMacros.h"
#import "HelloWorldANE_LIB.h"
#import <HelloWorldANE_FW/HelloWorldANE_FW.h>

#define FRE_OBJC_BRIDGE XXXX_FlashRuntimeExtensionsBridge // use unique prefix throughout to prevent clashes with other ANEs
@interface FRE_OBJC_BRIDGE : NSObject<FreSwiftBridgeProtocol>
@end
@implementation FRE_OBJC_BRIDGE {
}
FRE_OBJC_BRIDGE_FUNCS
@end

@implementation HelloWorldANE_LIB
SWIFT_DECL(XXXX) // use unique prefix throughout to prevent clashes with other ANEs
CONTEXT_INIT(XXXX) {
    SWIFT_INITS(XXXX)
    
    /**************************************************************************/
    /******* MAKE SURE TO ADD FUNCTIONS HERE THE SAME AS SWIFT CONTROLLER *****/
    /**************************************************************************/
    
    static FRENamedFunction extensionFunctions[] =
    {
        MAP_FUNCTION(XXXX, init)
    };
    
    
    
    /**************************************************************************/
    /**************************************************************************/
    
    SET_FUNCTIONS
    
}

CONTEXT_FIN(XXXX) {
    [XXXX_swft dispose];
    XXXX_swft = nil;
    XXXX_freBridge = nil;
    XXXX_swftBridge = nil;
    XXXX_funcArray = nil;
}
EXTENSION_INIT(XXXX)
EXTENSION_FIN(XXXX)
@end
