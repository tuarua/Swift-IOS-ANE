#!/bin/sh

wget https://github.com/tuarua/Swift-IOS-ANE/releases/download/1.4.0-beta/ios_dependencies.zip
unzip -u -o ios_dependencies.zip
rm ios_dependencies.zip
